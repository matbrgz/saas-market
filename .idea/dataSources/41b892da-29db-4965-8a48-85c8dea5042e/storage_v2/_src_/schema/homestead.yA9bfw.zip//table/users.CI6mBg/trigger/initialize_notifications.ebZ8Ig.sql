create trigger initialize_notifications
  after INSERT
  on users
  for each row
  INSERT INTO notifications (user_id, target, count) VALUES (NEW.id, "newsfeed", 0), (NEW.id, "files", 0), (NEW.id, "posts", 0);

