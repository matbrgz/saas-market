create trigger increment_notifications_files
  after INSERT
  on files
  for each row
  UPDATE notifications SET count = count+1 

WHERE notifications.user_id != NEW.user_id 
AND   notifications.target = "files";

