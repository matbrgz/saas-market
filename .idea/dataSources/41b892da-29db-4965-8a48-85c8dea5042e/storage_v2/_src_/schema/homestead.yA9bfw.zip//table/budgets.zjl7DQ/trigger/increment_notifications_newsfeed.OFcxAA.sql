create trigger increment_notifications_newsfeed
  after INSERT
  on budgets
  for each row
  UPDATE notifications SET count = count+1 

WHERE notifications.user_id != NEW.user_id 
AND   notifications.target = "newsfeed";

